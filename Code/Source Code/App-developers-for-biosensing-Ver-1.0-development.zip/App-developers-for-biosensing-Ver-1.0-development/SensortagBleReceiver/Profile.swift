//
//  Profile.swift
//  SensortagBleReceiver
//
//  Created by bhansali on 10/27/16.
//  Copyright © 2016 Yuuki NISHIYAMA. All rights reserved.
//

import UIKit

class Profile: UIViewController {

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

   

}
